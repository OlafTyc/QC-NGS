This is the FastQ Screen Test Dataset. The file 'fqs_test_dataset.fastq.gz' contains 1,000 FASTQ (Sanger) format reads to be processed with FASTQ Screen, aligning against recent Human and Mouse genome builds.  Providing that the software has been configured correctly on your system, you should obtain results very similar to those reported in the files 'fqs_test_dataset_screen.txt', 'fqs_test_dataset_screen.png' and 'fqs_test_dataset_screen.html', which are also included in this TAR archive.

The FastQ Screen Homepage may be found at:
www.bioinformatics.babraham.ac.uk/projects/fastq_screen